import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes: Recipe[] = [
    new Recipe('15 Comforting Low-Carb Soups',
    "From creamy favorites like faux potato soup to hearty beef cabbage stew, you won't miss the carbs with these flavorful low-carb soups",
    'https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F43%2F2020%2F06%2F18%2F4578566-2000.jpg&w=426&h=285&c=sc&poi=face&q=85'),
    new Recipe('10 Instant Pot Shrimp Recipes',
    'Make an effortless, elegant, and restaurant-worthy shrimp dinner at home with the help of your Instant Pot.',
    'https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F43%2F2020%2F12%2F27%2F278393_instant-pot-peel-and-eat-shrimp_photo-by-France-C-2000.jpeg&w=426&h=285&c=sc&poi=face&q=85'),
    new Recipe('10 Passover-Friendly Recipes Using Matzo Cake Meal',
    'Find loads of delicious ways to bake with matzo cake meal, from cookies to moist chocolate cakes and more.',
    'https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F43%2F2021%2F03%2F24%2F217024-passover-chocolate-chip-cookies-Andi-2000.jpg&w=426&h=285&c=sc&poi=face&q=85')
  ]
  @Output() recipeSelected = new EventEmitter<Recipe>();
  constructor() { }

  ngOnInit(): void {
  }

  selectRecipe(recipe: Recipe){
    this.recipeSelected.emit(recipe);
  }
}
